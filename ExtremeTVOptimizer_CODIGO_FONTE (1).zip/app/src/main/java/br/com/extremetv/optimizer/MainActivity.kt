package br.com.extremetv.optimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import android.content.pm.ResolveInfo

private val Bg = Color(0xFF0B0E14)
private val Panel = Color(0xFF151B25)
private val Gold = Color(0xFFD6AD5B)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExtremeHome() }
    }
}

data class TvApp(val label: String, val packageName: String)

@Composable
fun ExtremeHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Início") }
    var apps by remember { mutableStateOf(emptyList<TvApp>()) }
    var ram by remember { mutableStateOf("—") }
    var storage by remember { mutableStateOf("—") }

    fun refresh() {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0).map { ri: ResolveInfo ->
            TvApp(ri.loadLabel(pm).toString(), ri.activityInfo.packageName)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        ram = "${Formatter.formatFileSize(context, mi.availMem)} livres"
        val fs = StatFs(context.filesDir.absolutePath)
        storage = "${Formatter.formatFileSize(context, fs.availableBytes)} livres"
    }
    LaunchedEffect(Unit) { refresh() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Gold, onBackground = Color.White, onSurface = Color.White)) {
        Row(Modifier.fillMaxSize().background(Bg).padding(28.dp)) {
            Column(Modifier.width(200.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("EXTREME", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("TV OPTIMIZER", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(24.dp))
                    listOf("Início", "Aplicativos", "Desempenho", "Configurações").forEach { item ->
                        val active = tab == item
                        Box(Modifier.fillMaxWidth().background(if (active) Panel else Color.Transparent, RoundedCornerShape(12.dp))
                            .border(if (active) 1.dp else 0.dp, if (active) Gold.copy(alpha=.7f) else Color.Transparent, RoundedCornerShape(12.dp))
                            .clickable { tab = item }.focusable().padding(15.dp)) {
                            Text(item, color = if (active) Gold else Color.White, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                        }
                    }
                }
                Text("VERSÃO 1.0  •  ANDROID TV", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.width(28.dp))
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(when(tab) { "Aplicativos" -> "Sua biblioteca"; "Desempenho" -> "Saúde da TV"; "Configurações" -> "Ajustes rápidos"; else -> "Sua TV. Do seu jeito." }, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("Uma experiência mais limpa, simples e organizada.", color = Muted, fontSize = 13.sp)
                    }
                    Text("EXTREME  ◆", color = Gold, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(24.dp))
                when(tab) {
                    "Início" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            InfoCard("RAM DISPONÍVEL", ram, Modifier.weight(1f))
                            InfoCard("ESPAÇO LIVRE*", storage, Modifier.weight(1f))
                            InfoCard("APLICATIVOS", apps.size.toString(), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(26.dp)); Text("ACESSO RÁPIDO", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(12.dp)); AppStrip(apps.take(12)) { openApp(context, it.packageName) }
                    }
                    "Aplicativos" -> { Text("${apps.size} aplicativos com suporte à TV", color = Muted); Spacer(Modifier.height(14.dp)); AppStrip(apps) { openApp(context, it.packageName) } }
                    "Desempenho" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { InfoCard("RAM DISPONÍVEL", ram, Modifier.weight(1f)); InfoCard("ESPAÇO LIVRE*", storage, Modifier.weight(1f)) }
                        Spacer(Modifier.height(10.dp))
                        ActionCard("Armazenamento", "Abrir as configurações oficiais") { safeStart(context, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
                        ActionCard("Aplicativos instalados", "Revisar, limpar cache ou desinstalar manualmente") { safeStart(context, Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)) }
                        ActionCard("Atualizar diagnóstico", "Consultar novamente os indicadores") { refresh() }
                        Text("*Espaço disponível na área de dados acessível ao aplicativo.", color = Muted, fontSize = 10.sp)
                    }
                    else -> {
                        ActionCard("Configurações do Android", "Abrir configurações da televisão") { safeStart(context, Intent(Settings.ACTION_SETTINGS)) }
                        ActionCard("Rede", "Abrir configurações de rede") { safeStart(context, Intent(Settings.ACTION_WIFI_SETTINGS)) }
                        ActionCard("Gerenciar Extreme TV Optimizer", "Informações e permissões do aplicativo") { safeStart(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                    }
                }
            }
        }
    }
}

@Composable fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(15.dp)).padding(15.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp)); Text(value, color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun AppStrip(apps: List<TvApp>, onOpen: (TvApp) -> Unit) {
    if (apps.isEmpty()) Text("Nenhum aplicativo compatível com a interface de TV foi encontrado.", color = Muted)
    else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(apps, key = { it.packageName }) { app ->
            Column(Modifier.width(145.dp).height(118.dp).background(Panel, RoundedCornerShape(14.dp)).clickable { onOpen(app) }.focusable().padding(12.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(app.label.take(25), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2)
                Spacer(Modifier.height(8.dp)); Text("ABRIR  ›", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable fun ActionCard(title: String, subtitle: String, action: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(Panel, RoundedCornerShape(13.dp)).clickable { action() }.focusable().padding(15.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

private fun openApp(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) runCatching { context.startActivity(intent) }
}
private fun safeStart(context: Context, intent: Intent) {
    runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
